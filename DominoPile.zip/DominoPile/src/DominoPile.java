import java.util.ArrayList;

public class DominoPile {

    private ArrayList<Domino> pile;

    public DominoPile() {
        pile = new ArrayList();
    }

    // { (0,0), (0,1), (0,2), ... (6,6) }
    public void newStack6() {
        for (int i = 0; i < 7; i++) {
            for (int j = i; j < 7; j++) {
                Domino domino = new Domino(i, j);
                pile.add(domino);
            }
        }

    }

    public ArrayList<Domino> getPile() {
        return pile;
    }

    public void shuffleOptionOne() {

        ArrayList<Domino> pileRandomOrder = new ArrayList<>();

        while (!pile.isEmpty()) {

            int randomIndex = (int) (Math.random() * pile.size());
            pileRandomOrder.add(pile.remove(randomIndex));

        }

        pile = pileRandomOrder;
    }

    public void shuffleOptionTwo() {

        for (int i = 0; i < 1000; i++) {

            int randomIndex1 = (int) (Math.random()*pile.size());
            int randomIndex2 = (int) (Math.random()*pile.size());

            Domino dominoOne = pile.get(randomIndex1);
            Domino dominoTwo = pile.get(randomIndex2);

            pile.set(randomIndex1, dominoTwo);
            pile.set(randomIndex2, dominoOne);
        }
    }

}
