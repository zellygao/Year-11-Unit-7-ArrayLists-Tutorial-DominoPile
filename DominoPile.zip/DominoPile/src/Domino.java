public class Domino {

    private int top;
    private int bottom;

    public Domino() {
        top = 0;
        bottom = 0;
    }

    public Domino(int top, int bottom) {
        this.top = top;
        this.bottom = bottom;
    }

    public int getTop() {
        return top;
    }

    public int getBottom() {
        return bottom;
    }

    public void setBottom(int bottom) {
        this.bottom = bottom;
    }

    public void setTop(int top) {
        this.top = top;
    }

    @Override
    public String toString() {
        return top + "/" + bottom;
    }

    public void flip() {
        int temp = bottom;
        bottom = top;
        top = temp;
    }

    public void settle() {
        if (bottom < top) flip();
    }

    public int compareTo(Domino other) {
        int totalThis = top + bottom;
        int totalOther = other.getTop() + other.getBottom();

        if (totalThis < totalOther) return -1;
        if (totalThis > totalOther) return 1;
        return 0;
    }

    public boolean canConnect(Domino other) {

        return (top == other.top || top == other.bottom || bottom == other.top || bottom == other.bottom);

    }
}
